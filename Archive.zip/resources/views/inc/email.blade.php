<p>
    Hi, <br>
    You have a new message from lekslign website <br><br>
    <strong>Name:</strong> {{$data['name']}} <br>
    <strong>Email:</strong> {{$data['email']}} <br>
    <strong>Message:</strong> <em>{{$data['message']}}</em>
</p>