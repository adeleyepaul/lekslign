<p>
    Hi, <br>
    You have a new message from lekslign website <br><br>
    <strong>Name:</strong> <?php echo e($data['name']); ?> <br>
    <strong>Email:</strong> <?php echo e($data['email']); ?> <br>
    <strong>Message:</strong> <em><?php echo e($data['message']); ?></em>
</p><?php /**PATH /Users/olu/Documents/projects/laravel/test/resources/views/inc/email.blade.php ENDPATH**/ ?>